#!/bin/bash
python3 parse_1688_v3.py
